import React from "react";

function CardItem(props){
    return (
        <div className="card">
            <div className="img-container">
            <img 
            src={props.image}
            alt={props.name}
            
            clicked={props.clicked} />
            </div>
            {/* onClick={ () => props.handleClick(props.id)} /> */}
        
        </div>

    )
}

export default CardItem;